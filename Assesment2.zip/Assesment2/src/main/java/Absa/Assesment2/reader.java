package Absa.Assesment2;
import java.io.FileInputStream;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;





public class reader {
//creating array of string to contain the data from excel
	public ArrayList<String>  MyExcel(int column)throws IOException {
		
		//getting the path to the file
		FileInputStream fis = new FileInputStream("/Assesment2/src/main/java/TestData/absa.xlsx");
		
		//creating work sheet/book
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		
		//assigning the work sheet
		XSSFSheet s = wb.getSheet("sheet1");
		
		//looping the rows of the file to get data
		Iterator<Row> rowIt=s.iterator();
		
		rowIt.next();
		
		ArrayList<String> list=new ArrayList<String>();
		
		while(rowIt.hasNext()) {
			//adding the data to the array list
			list.add(rowIt.next().getCell(column).getStringCellValue());	
		
		}
		
		return list;
	}


}
